## 58pic(千图网无水印解析下载)


### 调用方式1如下(浏览器显示链接+图片)
http://127.0.0.1/index.php?PicUrl=https://www.58pic.com/newpic/34816843.html

### 调用方式2如下(只显示解析后的连接)
http://127.0.0.1/index.php?PicUrl=https://www.58pic.com/newpic/34816843.html

### 显示解析后的图片
http://127.0.0.1/showPic.php?img_url=http://pic.qiantucdn.com/58pic/34/81/68/43g58PIC9ZK2GIjdy4Nff_PIC2018.jpg
