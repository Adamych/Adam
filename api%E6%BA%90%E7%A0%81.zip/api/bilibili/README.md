﻿﻿## bilibili封面图api调用
### 获取后直接跳转显示
http://127.0.0.1/index.php?AV_number=av51455288
### 获取封面图url
http://127.0.0.1/api.php?AV_number=av51455288